export const fontOptions = {
  x: 0,
  y: 0,
  fontSize: 14,
  anchor: "top",
  attributes: { fill: "#b2b2b2" }
};
// Distance to the edge
export const OFFSET = {
  X: 20,
  Y: 20
};
